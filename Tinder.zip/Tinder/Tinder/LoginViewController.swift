//
//  LoginViewController.swift
//  Tinder
//
//  Created by Kanav Bhatia on 19/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit
import Parse

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var loginOrSignupButton: UIButton!
    
    @IBOutlet weak var changeLoginSignupButton: UIButton!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func changedLoginOrSignupTapped(_ sender: Any) {
        if signupMode
        {
            loginOrSignupButton.setTitle("Log in", for: .normal)
            changeLoginSignupButton.setTitle("Sign up", for: .normal)
            signupMode = false
        }
        else
        {
            loginOrSignupButton.setTitle("Sign up", for: .normal)
            changeLoginSignupButton.setTitle("Log in", for: .normal)
            signupMode = true
            
        }
    }
    
    var signupMode = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorLabel.isHidden = true
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        //if user is already logged in then take him directly to the page
        if PFUser.current() != nil
        {
            //phele check user hai ki nahi
            if PFUser.current()?["isFemale"] != nil
            {
                self.performSegue(withIdentifier: "directSwipeSegue", sender: nil)
                //fir check info updated hai ki nahi
            }   else
                { //agar loggedin hai aur info updated nahi hai to second page lejaao
                self.performSegue(withIdentifier: "updateSegue", sender: nil)
                }
        }
    }
    @IBAction func loginOrSignupTapped(_ sender: Any) {
        
        if signupMode{
            let user = PFUser()
            user.username = usernameTextField.text
            user.password = passwordTextField.text
            user.signUpInBackground(block: {(success,error) in
                if error != nil{
                    var errorMessage = "Unable to sign up. Please try again"
                    
                    if let newError = error as NSError?{
                        if let detailedError = newError.userInfo["error"] as? String{
                            errorMessage = detailedError
                        }
                        
                    }
                    self.errorLabel.text = errorMessage
                    self.errorLabel.isHidden = false
                }
                else
                {
                    print("Sign up successful")
                    self.performSegue(withIdentifier: "updateSegue", sender: nil)
                }
            })
        }
        else{
            if let username = usernameTextField.text{
                if let password = passwordTextField.text{
                    PFUser.logInWithUsername(inBackground: username, password: password) { (user, error) in
                        if error != nil{
                            var errorMessage = "Unable to Log in. Please try again"
                            
                            if let newError = error as NSError?{
                                if let detailedError = newError.userInfo["error"] as? String{
                                    errorMessage = detailedError
                                }
                                
                            }
                            self.errorLabel.text = errorMessage
                            self.errorLabel.isHidden = false
                        }
                        else
                        {
                            print("Log in successful")
                            self.errorLabel.isHidden = true
                            if user?["isFemale"] != nil
                            {
                                self.performSegue(withIdentifier: "directSwipeSegue", sender: nil)
                                //fir check info updated hai ki nahi
                            }   else
                            { //agar loggedin hai aur info updated nahi hai to second page lejaao
                                self.performSegue(withIdentifier: "updateSegue", sender: nil)
                            }
                        }
                    }
                }
            }
        }
    
}
}
