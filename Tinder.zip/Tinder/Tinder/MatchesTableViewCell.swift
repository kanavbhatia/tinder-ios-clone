//
//  MatchesTableViewCell.swift
//  Tinder
//
//  Created by Kanav Bhatia on 20/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit
import Parse

class MatchesTableViewCell: UITableViewCell {

    @IBOutlet weak var messageLabel: UILabel!
    
    var reciepientObjectId = ""
    
    @IBOutlet weak var profileImageView: UIImageView!
    
    @IBAction func sendTapped(_ sender: Any) {
        
        //to send message
        let message = PFObject(className: "Message")
        message["Sender"] = PFUser.current()?.objectId
        message["Reciever"] = reciepientObjectId
        message["Content"] = messageTextField.text
        
         message.saveInBackground()
    }
    @IBOutlet weak var messageTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
