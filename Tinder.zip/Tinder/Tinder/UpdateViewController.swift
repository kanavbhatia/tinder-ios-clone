//
//  UpdateViewController.swift
//  Tinder
//
//  Created by Kanav Bhatia on 19/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit
import Parse

class UpdateViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate  {
    
    
    @IBAction func backPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorDisplay.isHidden = true
        // Do any additional setup after loading the view.
        //createWomen()
        
        // agar logged in hai to purana data fetch kare online
        if let isFemale = PFUser.current()?["isFemale"] as? Bool{
            userGenderSwitch.setOn(isFemale, animated: true)
        }
        if let isInterestedInFemale = PFUser.current()?["isInterestedInFemale"] as? Bool{
            interestedGenderSwitch.setOn(isInterestedInFemale, animated: true)
        }
        if let photo = PFUser.current()?["Photo"] as? PFFile{
            photo.getDataInBackground(block: { (data, error) in
                if let imageData = data {
                    if let image = UIImage(data: imageData){
                        self.profileImageViewer.image = image
                    }
                }
            })
            
        }
    }
    
    @IBOutlet weak var profileImageViewer: UIImageView!
    
    @IBAction func updateImageTapped(_ sender: Any) {
        
        let imagePickerController = UIImagePickerController()
        
        imagePickerController.delegate = self
        
        imagePickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
        
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func createWomen()
    { //creating a fake db
        let imageURLs = ["https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-1.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-2.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-3.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-4.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-5.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-6.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-8.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-9.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-11.jpg","https://cdn.lolwot.com/wp-content/uploads/2016/02/20-of-the-most-unbelievably-stunning-women-12.jpg"]
        
        var counter = 0
        
        for imageURL in imageURLs{
            counter = counter+1
            if let url = URL(string: imageURL){
                if let data = try? Data(contentsOf: url){
                    let imageFile = PFFile(name: "photo.jpg", data: data)
                    let user = PFUser()
                    user.username = String(counter)
                    user.password = "pass"
                    user["Photo"] = imageFile
                    user["isFemale"] = true
                    user["isInterestedInFemale"] = false
                    user.signUpInBackground { (success, error) in
                        if success{
                            print("Women data uploaded SUCCESSFULLY")
                        }
                        else
                        {
                            print("UNSUCCESSFUL data upload")
                        }
                    }
                }
            }
        }
    }
    
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            profileImageViewer.image = image
        }
        else {
            
            print("Image not loaded")
            
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var errorDisplay: UILabel!
    @IBOutlet weak var interestedGenderSwitch: UISwitch!
    
    @IBOutlet weak var userGenderSwitch: UISwitch!
    
    @IBAction func updateTapped(_ sender: Any) {
        
        PFUser.current()?["isFemale"] = userGenderSwitch.isOn
        PFUser.current()?["isInterestedInFemale"] = interestedGenderSwitch.isOn
        
        if let image = profileImageViewer.image
        {
            if let imageData = UIImagePNGRepresentation(image)
            {
                PFUser.current()?["Photo"] =  PFFile(name: "profile.png", data: imageData)
                PFUser.current()?.saveInBackground(block: { (success, error) in
                    if error != nil{
                        var errorMessage = "Unable to uodate Photo. Please try again"
                        
                        if let newError = error as NSError?{
                            if let detailedError = newError.userInfo["error"] as? String{
                                errorMessage = detailedError
                            }
                            
                        }
                        self.errorDisplay.text = errorMessage
                        self.errorDisplay.isHidden = false
                    }
                    else
                    {
                        print("Information uploaded successfully")
                        self.performSegue(withIdentifier: "updateSegue", sender: nil)
                    }
                })
            }
        }
        
    }
}
