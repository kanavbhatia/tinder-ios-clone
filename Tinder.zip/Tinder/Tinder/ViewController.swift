//
//  ViewController.swift
//  Tinder
//
//  Created by Kanav Bhatia on 18/08/18.
//  Copyright © 2018 Kanav Bhatia. All rights reserved.
//

import UIKit
import Parse

class ViewController: UIViewController {
    
    var displayUserId = ""
    
    @IBAction func messageWindow(_ sender: Any) {
        performSegue(withIdentifier: "toChatSegue", sender: nil)
    }
    
    @IBOutlet weak var titileName: UINavigationItem!
    
    @IBOutlet weak var matchImageView: UIImageView!
    
    @IBAction func updateProfile(_ sender: Any) {
        self.performSegue(withIdentifier: "updateProfileSegue", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // to have a palm drag
        let gesture = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gestureRecognizer:)))
        matchImageView.addGestureRecognizer(gesture)
        updateImage()
        //for accessing user's location
        PFGeoPoint.geoPointForCurrentLocation { (geoPoint, error) in
            if let point = geoPoint{
                PFUser.current()?["Location"] = point
                PFUser.current()?.saveInBackground()
          /*      if var name = self.titileName as? String{
                    name = PFUser.current()?["username"] as! String
                } */
            }
        }
        
    }
    @objc func wasDragged(gestureRecognizer: UIPanGestureRecognizer) {
        let labelPoint = gestureRecognizer.translation(in: view)
        //to move the label
        matchImageView.center = CGPoint(x: view.bounds.width/2 + labelPoint.x ,y: view.bounds.height/2 + labelPoint.y )
        //to drag the label back
        // print(matchImageView.center.x)
        
        let xFromCentre = view.bounds.width/2 - matchImageView.center.x
        // jaise hi ek taraf jayega width kam/jyada hogi rotation bhi ussi hisaab se hoyegi basically acting like a func
        
        let scale = min(100/abs(xFromCentre),1)
        //min isliye kyuki agar 1 se kam hui value to photo ulti ho rhi hai & abs makes -1 to 1 and 1 to 1
        // jaise jaise xcentre kam ki value badegi vaise hi square chota hogaa
        
        var rotation = CGAffineTransform(rotationAngle: xFromCentre/300)
        // CGAffineTransform is used for rotation
        
        var rotateAndScaled = rotation.scaledBy(x: scale, y: scale)
        // for rotating the scaled element
        
        matchImageView.transform = rotateAndScaled
        
        
        if gestureRecognizer.state == .ended{
            var acceptedOrRejected = ""
            if matchImageView.center.x < (20){
                print("Not Interested")
                acceptedOrRejected = "rejected"
            }
            if matchImageView.center.x > (350){
                print("Interested")
                acceptedOrRejected = "accepted"
            }
            if acceptedOrRejected != "" && displayUserId != ""{
                PFUser.current()?.addUniqueObject(displayUserId, forKey: acceptedOrRejected)  //jo bhi hoga accepted ya rejected vo acceptedOrRejected isme se lekar accpted ya rejected ke table me copy hojayega current user ka objectid from displayid so that vo user ke pass vapiss na aaye
                PFUser.current()?.saveInBackground(block: { (success, error) in
                    if success{
                        self.updateImage()      //ek bari select hone ke baad doosri image khul jaye
                    }
                })
            }
            
            matchImageView.center = CGPoint(x: view.bounds.width/2, y: view.bounds.height/2 )
            
            rotation = CGAffineTransform(rotationAngle: 0)
            
            rotateAndScaled = rotation.scaledBy(x: 1, y: 1)
            //ek bari intersted/ non hojaye to get back to original shape and rotation
            
            matchImageView.transform = rotateAndScaled
            
        }
    }
    
    @IBAction func logoutButton(_ sender: Any) {
        self.performSegue(withIdentifier: "logoutSegue", sender: nil)
        PFUser.logOut()
        print("Logout successfull")
    }
    func updateImage()
    {
        
        if let query = PFUser.query(){
            // to check jo interest hai vo gender bhi hai ki nahi
            if let isInterestedInFemale = PFUser.current()?["isInterestedInFemale"]{
                query.whereKey("isFemale", equalTo: isInterestedInFemale) // wherekey is used for comparing
            }
            if let isFemale = PFUser.current()?["isFemale"]{
                query.whereKey("isInterestedInFemale", equalTo: isFemale) // wherekey is used for comparing
            }
            var ignoredUsers: [String] = []
            //agar user accepted me ya rejected me aa chuka hai to usse hum ignoredusers me daal dege aur humme next unn users ko display karvana hai jo ignoredusers me naa aaye ho yani phele vo users na aaye ho
            
            if let acceptedUsers = PFUser.current()?["accepted"] as? [String]{
                ignoredUsers += acceptedUsers
            }
            if let rejectedUsers = PFUser.current()?["rejected"] as? [String]{
                ignoredUsers += rejectedUsers
            }
            query.whereKey("objectId", notContainedIn: ignoredUsers)
            query.limit = 1  //to have one user at a time
            //builds a box around the location
            if let geoPoint = PFUser.current()?["Location"] as? PFGeoPoint{
                query.whereKey("Location", withinGeoBoxFromSouthwest: PFGeoPoint(latitude: geoPoint.latitude - 1, longitude: geoPoint.longitude - 1), toNortheast: PFGeoPoint(latitude: geoPoint.latitude + 1, longitude: geoPoint.longitude + 1))}
            
            //to execute the query
            query.findObjectsInBackground { (objects, error) in
                if let users = objects{
                    for object in users{
                        if let user = object as? PFUser{
                            if let imageFile = user["Photo"] as? PFFile{
                                imageFile.getDataInBackground(block: { (data, error) in      //to download the image
                                    if let imageFile = data{
                                        self.matchImageView.image = UIImage(data: imageFile)
                                        if let objectID = object.objectId{
                                           self.displayUserId = objectID    //to get the objectid jiski bhi photo display ho rhi ho
                                        }
                                    }
                                })
                            }
                        }
                    }
                    
                }
                
            }
        }
        
    }
    
    
}

